import cresla.entities.containers.ModuleContainer;
import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.EnergyModule;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class Tetsts {

    private ModuleContainer container;
    private EnergyModule energyModule;
    private AbsorbingModule absorbingModule;

    @Before
    public void init()
    {
     this.container=new ModuleContainer(10);
     this.energyModule= Mockito.mock(EnergyModule.class);
     this.absorbingModule=Mockito.mock(AbsorbingModule.class);
    }

    @Test(expected = IllegalArgumentException.class)
    public void TestWithNull()
    {
      this.container.addEnergyModule(null);
    }
}
